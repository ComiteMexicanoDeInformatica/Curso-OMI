#include <iostream>

void main()
{
	int a, b;	

	std::cin >> a >> b;
	std::cout << a + b << std::endl;
}
